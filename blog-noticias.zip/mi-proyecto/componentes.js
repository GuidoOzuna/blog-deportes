const componentes = [
  {
    id: 1,
    nombre: 'Resistor',
    descripcion: 'Un resistor es un componente electrónico pasivo...',
    imagen: 'img/resistor.jpg'
  },
  {
    id: 2,
    nombre: 'Capacitor',
    descripcion: 'Un capacitor es un dispositivo que almacena energía eléctrica...',
    imagen: 'img/capacitor.jpg'
  },
  // Agrega más componentes aquí
];

module.exports = componentes;